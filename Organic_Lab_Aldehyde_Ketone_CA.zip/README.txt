ORGANIC LAB — Aldehydes, Ketones & Carboxylic Acids

FILES
- index.html: main front-end / chapter selector
- styles.css: responsive interface
- app.js: quiz engine, selection, scoring, local save/resume, analysis
- aldehyde-ketone-ca.js: chapter registry and complete static question bank

RUN
1. Keep all four files in the same folder.
2. Open index.html in a modern browser, or deploy the folder to GitHub Pages.
3. Internet is not required for quiz logic or saving. The optional Google Font may fall back to system fonts.

QUESTION BANK
- 8 subtopics
- 30 questions per subtopic (6 core learning points × 5 phase formats)
- 5 phases: Concept Building, Memory Checking, Application, Reaction & Reasoning, Exam Challenge
- 240 questions total, all loaded locally at once. No API or runtime question generation.

SAVING
Progress and attempts are stored in browser localStorage on that device/browser. Clearing browser site data or changing browser/device may remove or make the saved record unavailable. Use the same browser and deployment origin to resume.
